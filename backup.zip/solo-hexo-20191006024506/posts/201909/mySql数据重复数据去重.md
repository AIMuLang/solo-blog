title: mySql数据重复数据去重
date: '2019-09-20 15:34:29'
updated: '2019-09-20 16:18:04'
tags: [mysql]
permalink: /articles/2019/09/20/1568964869591.html
---
![](https://img.hacpai.com/bing/20180601.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1、问题来源：数据中由于并发问题，数据存在多次调用接口，插入了重复数据，需要根据多条件删除重复数据；

2、参考博客文章地址：[https://www.cnblogs.com/jiangxiaobo/p/6589541.html](https://www.cnblogs.com/jiangxiaobo/p/6589541.html)

二、

1、删除数据之前，先要查找到重复的数据，有一张单位表，单位名称可以重复，但是在不同组织id下不能重复，统计一下重复的数据

select count(company_name) countNum ,company_name,org_id from company group by company_name,org_id having countNum>1 order by countNum desc

 查询结果
![](https://img2018.cnblogs.com/blog/1675975/201906/1675975-20190618165852012-1893422819.png)

2、删除重复数据：根据数据查询出的条件筛选出重复数据的id，然后将id最小的排除掉，然后删除这些重复数据，中间由于数据库版本的问题，不能直接在查询表的数据删除数据

所以需要创建一张中间表进行删除

```mysql
delete from company WHERE id in (
SELECT t.id FROM (
select id 
FROM
    company a
WHERE
    (a.company_name, a.org_id) IN (
        SELECT
            company_name,
            org_id
        FROM
            company
        GROUP BY
            company_name,
            org_id
        HAVING
            count(*) > 1
    )
AND id NOT IN (
    SELECT
        min(id)
    FROM
        company
    GROUP BY
        company_name,
        org_id
    HAVING
        count(*) > 1
)) t);

```
